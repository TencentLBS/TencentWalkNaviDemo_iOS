//
//  TWNBaseNaviManager.h
//  TWNNavigationKit
//
//  Created by Zhang Tian on 2019/3/5.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  @brief 导航控制类基类
 */
@interface TWNBaseNaviManager : NSObject

@end
